# Plan — QA & Stabilization Pass on Lumen Engine

## Goal
Audit engine + templates + examples for runtime risks, browser compat, mobile responsiveness, asset pipeline edge cases. Propose fixes, apply them, deliver stable production-ready version.

## Stages
1. **QA Audit** — read-only QA agent reviews all packages (focus: runtime/, rendering/, assets/, interaction/ for runtime risks + browser compat + mobile; assets/ for edge cases; templates + examples). Output: severity-ranked findings with file refs and fix proposals → qa-report.md.
2. **Fixes** — Stabilization coder agent applies approved fixes on branch agent/qa-fixes (respecting Do-NOT stability constraints from refactor-proposal.md §4: no public API renames, no wire format changes).
3. **Validate** — orchestrator: build-all + all package tests + e2e + all 3 example builds. Report stable version.
