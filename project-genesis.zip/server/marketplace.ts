export const privacyTiers = ["PUBLIC", "SOFT", "SHADOW", "GHOST"] as const;
export type PrivacyTier = (typeof privacyTiers)[number];

export type DemoModel = {
  id: string;
  name: string;
  architecture: string;
  size: string;
  context: string;
  benchmark: number;
  latency: number;
  availability: number;
  basePrice: number;
  specialty: string;
  tags: string[];
};

export type DemoProvider = {
  id: string;
  name: string;
  region: string;
  status: "online" | "warming" | "degraded";
  gpu: string;
  cpu: string;
  capacity: number;
  heartbeat: number;
  reputation: number;
  earnings: number;
  payout: string;
};

export type SimulatedJob = {
  id: string;
  modelId: string;
  modelName: string;
  privacy: PrivacyTier;
  units: number;
  providers: number;
  status: "pending" | "running" | "completed" | "failed";
  estimate: number;
  createdAt: string;
  retryCount: number;
};

export const models: DemoModel[] = [
  { id: "bert-sentiment-v4", name: "BERT Sentiment v4", architecture: "Transformer", size: "438 MB", context: "512 tokens", benchmark: 96.4, latency: 38, availability: 99.98, basePrice: 0.021, specialty: "Classification", tags: ["Sentiment", "Social", "Fast"] },
  { id: "atlas-embed-3", name: "Atlas Embed 3", architecture: "Encoder", size: "1.2 GB", context: "8k tokens", benchmark: 94.1, latency: 26, availability: 99.94, basePrice: 0.015, specialty: "Embeddings", tags: ["Search", "RAG", "Multilingual"] },
  { id: "vision-lattice-2", name: "Vision Lattice 2", architecture: "ViT-LLM", size: "4.6 GB", context: "4k tokens", benchmark: 91.8, latency: 112, availability: 99.87, basePrice: 0.084, specialty: "Vision", tags: ["Image", "OCR", "Analysis"] },
  { id: "orion-code-7b", name: "Orion Code 7B", architecture: "Decoder", size: "13.4 GB", context: "32k tokens", benchmark: 88.7, latency: 94, availability: 99.76, basePrice: 0.067, specialty: "Code", tags: ["Code", "Agents", "Tools"] },
  { id: "whisper-stream-xl", name: "Whisper Stream XL", architecture: "Seq2Seq", size: "2.9 GB", context: "30 sec audio", benchmark: 93.6, latency: 71, availability: 99.91, basePrice: 0.042, specialty: "Speech", tags: ["ASR", "Realtime", "Audio"] },
  { id: "aether-reasoner-14b", name: "Aether Reasoner 14B", architecture: "MoE", size: "28.1 GB", context: "64k tokens", benchmark: 92.3, latency: 176, availability: 99.64, basePrice: 0.118, specialty: "Reasoning", tags: ["Planning", "Analysis", "Long context"] },
];

export const providers: DemoProvider[] = [
  { id: "orbital-07", name: "Orbital-07", region: "Helsinki", status: "online", gpu: "2× H100 SXM", cpu: "64 vCPU", capacity: 91, heartbeat: 0.8, reputation: 99.3, earnings: 284.72, payout: "3h 12m" },
  { id: "sable-mesh", name: "Sable Mesh", region: "Montreal", status: "online", gpu: "8× L40S", cpu: "96 vCPU", capacity: 74, heartbeat: 1.1, reputation: 98.7, earnings: 211.08, payout: "3h 12m" },
  { id: "cinder-12", name: "Cinder-12", region: "Osaka", status: "warming", gpu: "4× A100 80G", cpu: "48 vCPU", capacity: 43, heartbeat: 2.4, reputation: 97.9, earnings: 187.44, payout: "3h 12m" },
  { id: "northstar-lab", name: "Northstar Lab", region: "Reykjavík", status: "online", gpu: "1× H200", cpu: "32 vCPU", capacity: 88, heartbeat: 0.9, reputation: 99.8, earnings: 176.91, payout: "3h 12m" },
  { id: "dawn-compute", name: "Dawn Compute", region: "Singapore", status: "degraded", gpu: "4× RTX 6000 Ada", cpu: "64 vCPU", capacity: 52, heartbeat: 5.8, reputation: 96.4, earnings: 132.27, payout: "3h 12m" },
];

const simulatedJobs: SimulatedJob[] = [
  { id: "job_81f4d", modelId: "atlas-embed-3", modelName: "Atlas Embed 3", privacy: "SOFT", units: 240000, providers: 24, status: "completed", estimate: 18.42, createdAt: "12:42:10", retryCount: 0 },
  { id: "job_7c2aa", modelId: "vision-lattice-2", modelName: "Vision Lattice 2", privacy: "PUBLIC", units: 800, providers: 4, status: "running", estimate: 2.68, createdAt: "12:39:42", retryCount: 1 },
  { id: "job_c18e0", modelId: "bert-sentiment-v4", modelName: "BERT Sentiment v4", privacy: "SHADOW", units: 1000000, providers: 100, status: "pending", estimate: 42.7, createdAt: "12:36:08", retryCount: 0 },
];

export function quoteJob(modelId: string, units: number, privacy: PrivacyTier, splitCount: number) {
  const model = models.find((item) => item.id === modelId) ?? models[0];
  const privacyMultiplier: Record<PrivacyTier, number> = { PUBLIC: 1, SOFT: 1.08, SHADOW: 1.19, GHOST: 1.34 };
  const demandMultiplier = 1.072;
  const volume = Math.max(1, units / 1000);
  const parallelCredit = Math.min(0.12, Math.max(0, splitCount - 1) * 0.001);
  const total = Math.max(0.01, model.basePrice * volume * privacyMultiplier[privacy] * demandMultiplier * (1 - parallelCredit));
  const marketplaceFee = total * 0.06;
  const providerPayout = total - marketplaceFee;
  const bids = providers
    .filter((provider) => provider.status !== "degraded")
    .slice(0, 3)
    .map((provider, index) => ({
      provider: provider.name,
      reputation: provider.reputation,
      latency: Math.round((model.latency + provider.heartbeat * 10) * (1 + index * 0.08)),
      bid: Number((total * (0.93 + index * 0.045)).toFixed(2)),
      selected: index === 0,
    }));
  return {
    model,
    total: Number(total.toFixed(2)),
    marketplaceFee: Number(marketplaceFee.toFixed(2)),
    providerPayout: Number(providerPayout.toFixed(2)),
    pricePerThousand: Number((total / volume).toFixed(4)),
    auctionRange: [Number((total * 0.93).toFixed(2)), Number((total * 1.08).toFixed(2))],
    bids,
  };
}

export function getOverview() {
  return {
    models,
    providers,
    jobs: simulatedJobs,
    wallet: {
      balance: 1284.82,
      escrow: 42.7,
      earnedToday: 84.18,
      settledToday: 19.41,
      settlements: [
        { id: "set_2a91", label: "Atlas Embed 3 · 240k vectors", amount: 18.42, state: "settled", time: "12:43" },
        { id: "set_1d04", label: "BERT Sentiment v4 · 1M tweets", amount: 42.7, state: "escrow", time: "12:36" },
        { id: "set_9c31", label: "Vision Lattice 2 · 800 frames", amount: 2.68, state: "settled", time: "12:12" },
      ],
    },
    network: {
      activeNodes: 1248,
      throughput: 18.6,
      successRate: 99.42,
      failureRate: 0.58,
      medianLatency: 83,
      nodesDelta: 8.2,
      throughputSeries: [9, 11, 10, 14, 13, 16, 15, 18, 17, 21, 19, 24, 20, 23, 22, 26, 24, 28, 25, 29],
      latencyMesh: [31, 38, 47, 58, 66, 75, 84, 91, 108, 54, 43, 37, 63, 72, 80, 95, 116, 127, 42, 52, 68, 81, 97, 109, 34, 49, 61, 75, 86, 103],
    },
    pricing: { demand: 72, supply: 64, index: 1.072, updatedAt: "just now" },
  };
}

export function listModels(search = "", specialty = "all") {
  const normalizedSearch = search.trim().toLowerCase();
  return models.filter((model) => {
    const matchesSearch = !normalizedSearch || [model.name, model.architecture, model.specialty, ...model.tags].join(" ").toLowerCase().includes(normalizedSearch);
    const matchesSpecialty = specialty === "all" || model.specialty.toLowerCase() === specialty.toLowerCase();
    return matchesSearch && matchesSpecialty;
  });
}

export function submitSimulatedJob(input: { modelId: string; units: number; privacy: PrivacyTier; providers: number }) {
  const quote = quoteJob(input.modelId, input.units, input.privacy, input.providers);
  const job: SimulatedJob = {
    id: `job_${Math.random().toString(36).slice(2, 7)}`,
    modelId: quote.model.id,
    modelName: quote.model.name,
    privacy: input.privacy,
    units: input.units,
    providers: input.providers,
    status: "pending",
    estimate: quote.total,
    createdAt: "just now",
    retryCount: 0,
  };
  simulatedJobs.unshift(job);
  return { job, quote };
}
