import { describe, expect, it } from "vitest";
import { getOverview, quoteJob, submitSimulatedJob } from "./marketplace";

describe("Project Genesis simulation", () => {
  it("applies a higher privacy premium to SHADOW than PUBLIC", () => {
    const publicQuote = quoteJob("bert-sentiment-v4", 1000000, "PUBLIC", 100);
    const shadowQuote = quoteJob("bert-sentiment-v4", 1000000, "SHADOW", 100);

    expect(shadowQuote.total).toBeGreaterThan(publicQuote.total);
    expect(shadowQuote.providerPayout + shadowQuote.marketplaceFee).toBeCloseTo(shadowQuote.total, 1);
  });

  it("creates a pending job with the exact simulated routing inputs", () => {
    const result = submitSimulatedJob({ modelId: "atlas-embed-3", units: 50000, privacy: "SOFT", providers: 12 });

    expect(result.job.status).toBe("pending");
    expect(result.job.providers).toBe(12);
    expect(getOverview().jobs.some((job) => job.id === result.job.id)).toBe(true);
  });
});
