import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { getOverview, listModels, privacyTiers, quoteJob, submitSimulatedJob } from "./marketplace";

const privacyTierSchema = z.enum(privacyTiers);

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  demo: router({
    overview: publicProcedure.query(() => getOverview()),
    listModels: publicProcedure
      .input(z.object({ search: z.string().default(""), specialty: z.string().default("all") }))
      .query(({ input }) => listModels(input.search, input.specialty)),
    quote: publicProcedure
      .input(z.object({ modelId: z.string(), units: z.number().int().min(1).max(1000000), privacy: privacyTierSchema, providers: z.number().int().min(1).max(100) }))
      .query(({ input }) => quoteJob(input.modelId, input.units, input.privacy, input.providers)),
    submitJob: publicProcedure
      .input(z.object({ modelId: z.string(), units: z.number().int().min(1).max(1000000), privacy: privacyTierSchema, providers: z.number().int().min(1).max(100) }))
      .mutation(({ input }) => submitSimulatedJob(input)),
  }),
});

export type AppRouter = typeof appRouter;
