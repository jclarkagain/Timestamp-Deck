import { useState } from "react";
import type { Project } from "../types";
import { secureWriteClipboard } from "../utils/secureClipboard";
import { encryptProject } from "../utils/crypto";
import { downloadFile } from "../utils/download";
import { EncryptModal } from "./EncryptModal";

type Props = {
  project: Project;
  secureMode: boolean;
};

type PendingAction = "clipboard" | "download" | null;

export function ExportPanel({ project, secureMode }: Props) {
  const [pendingAction, setPendingAction] = useState<PendingAction>(null);

  const exportJSON = async () => {
    if (secureMode) {
      const ok = confirm(
        "Secure Mode is ON.\nThis export is NOT encrypted.\nContinue?"
      );
      if (!ok) return;
    }
    await secureWriteClipboard(JSON.stringify(project, null, 2), secureMode);
    alert("Project copied as JSON.");
  };

  const exportText = async () => {
    if (secureMode) {
      const ok = confirm(
        "Secure Mode is ON.\nThis export is NOT encrypted.\nContinue?"
      );
      if (!ok) return;
    }
    const lines: string[] = [];
    for (const v of project.videos) {
      lines.push(`Video: ${v.title}`);
      lines.push(`URL: ${v.url}`);
      for (const ts of v.timestamps) {
        lines.push(`  - ${ts.timeSeconds}s — ${ts.label}`);
      }
      lines.push("");
    }
    await secureWriteClipboard(lines.join("\n"), secureMode);
    alert("Project copied as text.");
  };

  const handleEncryptConfirm = async (password: string) => {
    const action = pendingAction;
    setPendingAction(null);
    if (!action) return;

    try {
      const payload = await encryptProject(project, password);
      const json = JSON.stringify(payload, null, 2);

      if (action === "clipboard") {
        await secureWriteClipboard(json, secureMode);
        alert("Encrypted project copied.");
      } else {
        const filename = `project-${Date.now()}.tdenc`;
        downloadFile(filename, json);
        alert(`Encrypted file downloaded: ${filename}`);
      }
    } catch (err) {
      console.error(err);
      alert("Encryption failed. Please try again.");
    }
  };

  return (
    <div>
      <h3>Project Export</h3>
      <button onClick={exportJSON}>Copy JSON</button>
      <button onClick={exportText}>Copy Text</button>
      <button onClick={() => setPendingAction("clipboard")}>
        Encrypt & Copy
      </button>
      <button onClick={() => setPendingAction("download")}>
        Download Encrypted File
      </button>

      <EncryptModal
        isOpen={pendingAction !== null}
        title="Set Encryption Password"
        onConfirm={handleEncryptConfirm}
        onClose={() => setPendingAction(null)}
      />
    </div>
  );
}
