import { useMemo, useState } from "react";
import type { Project, GlobalTimestamp } from "../types";
import { marked } from "marked";

type Props = {
  project: Project;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onJump: (videoId: string, seconds: number) => void;
};

type Grouped = {
  videoId: string;
  videoTitle: string;
  videoUrl: string;
  timestamps: GlobalTimestamp[];
};

const formatTime = (seconds: number): string => {
  const s = Math.floor(seconds % 60);
  const m = Math.floor((seconds / 60) % 60);
  const h = Math.floor(seconds / 3600);
  const pad = (n: number) => n.toString().padStart(2, "0");
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
};

export function GlobalTimeline({
  project,
  searchQuery,
  setSearchQuery,
  onJump
}: Props) {
  const rawGroups = useMemo<Grouped[]>(() => {
    return project.videos
      .map((video) => ({
        videoId: video.id,
        videoTitle: video.title || video.url,
        videoUrl: video.url,
        timestamps: video.timestamps.map((ts) => ({
          id: ts.id,
          videoId: video.id,
          videoTitle: video.title || video.url,
          videoUrl: video.url,
          timeSeconds: ts.timeSeconds,
          label: ts.label,
          notes: ts.notes
        }))
      }))
      .filter((g) => g.timestamps.length > 0);
  }, [project]);

  const filteredGroups = useMemo(() => {
    if (!searchQuery.trim()) return rawGroups;
    const q = searchQuery.trim().toLowerCase();
    return rawGroups
      .map((group) => ({
        ...group,
        timestamps: group.timestamps.filter((ts) => {
          const labelMatch = ts.label.toLowerCase().includes(q);
          const notesMatch = ts.notes?.toLowerCase().includes(q) ?? false;
          return labelMatch || notesMatch;
        })
      }))
      .filter((g) => g.timestamps.length > 0);
  }, [rawGroups, searchQuery]);

  const [expanded, setExpanded] = useState<Record<string, boolean>>(() => {
    const state: Record<string, boolean> = {};
    for (const g of rawGroups) state[g.videoId] = true;
    return state;
  });

  const toggleGroup = (videoId: string) => {
    setExpanded((prev) => ({ ...prev, [videoId]: !prev[videoId] }));
  };

  const total = filteredGroups.reduce(
    (acc, g) => acc + g.timestamps.length,
    0
  );

  return (
    <div className="global-timeline">
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
          marginBottom: "16px"
        }}
      >
        <h2 style={{ margin: 0 }}>Global Timeline</h2>
        <span
          style={{
            fontSize: "0.85em",
            color: "#666",
            marginLeft: "auto"
          }}
        >
          {total} timestamps
        </span>
      </div>

      <div style={{ display: "flex", gap: "8px", marginBottom: "16px" }}>
        <input
          type="text"
          placeholder="Search by label or notes..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{
            flex: 1,
            padding: "8px 12px",
            border: "1px solid #ccc",
            borderRadius: "4px"
          }}
        />
        {searchQuery && (
          <button onClick={() => setSearchQuery("")}>✕ Clear</button>
        )}
      </div>

      {filteredGroups.length === 0 ? (
        <p>
          {searchQuery.trim()
            ? `No timestamps match "${searchQuery.trim()}".`
            : "No timestamps yet."}
        </p>
      ) : (
        filteredGroups.map((group) => (
          <div key={group.videoId} className="group-section">
            <div
              className="group-header"
              onClick={() => toggleGroup(group.videoId)}
              style={{
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                padding: "8px 0",
                borderBottom: "1px solid #ddd",
                fontWeight: "bold"
              }}
            >
              <span>{expanded[group.videoId] ? "▼" : "▶"}</span>
              <span>{group.videoTitle}</span>
              <span style={{ fontSize: "0.8em", color: "#666" }}>
                ({group.timestamps.length})
              </span>
            </div>

            {expanded[group.videoId] && (
              <ul style={{ listStyle: "none", padding: "0 0 0 20px" }}>
                {group.timestamps.map((item) => (
                  <li
                    key={item.id}
                    style={{
                      padding: "8px 0",
                      borderBottom: "1px solid #eee",
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      flexWrap: "wrap",
                      gap: "4px"
                    }}
                  >
                    <div>
                      <strong>{formatTime(item.timeSeconds)}</strong> —{" "}
                      {item.label}
                      {item.notes && (
                        <div
                          style={{
                            fontSize: "0.85em",
                            color: "#555",
                            marginTop: "4px",
                            background: "#f0f0f0",
                            padding: "4px 8px",
                            borderRadius: "4px"
                          }}
                          dangerouslySetInnerHTML={{
                            __html: marked.parse(item.notes) as string
                          }}
                        />
                      )}
                    </div>
                    <button
                      onClick={() => onJump(item.videoId, item.timeSeconds)}
                    >
                      Jump
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))
      )}
    </div>
  );
}
