import { useState } from "react";
import type { VideoEntry, Timestamp } from "../types";
import {
  DragDropContext,
  Droppable,
  Draggable,
  DropResult
} from "@hello-pangea/dnd";
import { TimestampNotesModal } from "./TimestampNotesModal";

type Props = {
  video: VideoEntry;
  onChange: (updated: VideoEntry) => void;
  onSeek?: (seconds: number) => void;
  onCapture?: () => number | undefined;
};

const formatTime = (seconds: number): string => {
  const s = Math.floor(seconds % 60);
  const m = Math.floor((seconds / 60) % 60);
  const h = Math.floor(seconds / 3600);
  const pad = (n: number) => n.toString().padStart(2, "0");
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
};

export function TimestampPanel({
  video,
  onChange,
  onSeek,
  onCapture
}: Props) {
  const [editingNotes, setEditingNotes] = useState<Timestamp | null>(null);

  const addTimestampManual = () => {
    const input = prompt("Enter time (seconds):");
    if (!input) return;
    const timeSeconds = Number(input);
    if (Number.isNaN(timeSeconds)) return;

    const label = prompt("Label for this timestamp?") ?? "";
    const newTs: Timestamp = {
      id: `ts-${Date.now()}`,
      timeSeconds,
      label
    };
    onChange({ ...video, timestamps: [...video.timestamps, newTs] });
  };

  const handleCapture = () => {
    if (!onCapture) return;
    const time = onCapture();
    if (time == null) {
      alert("Player not ready.");
      return;
    }
    const label = prompt("Label for this timestamp?") ?? "";
    const newTs: Timestamp = {
      id: `ts-${Date.now()}`,
      timeSeconds: Math.floor(time),
      label
    };
    onChange({ ...video, timestamps: [...video.timestamps, newTs] });
  };

  const updateTimestamp = (id: string, patch: Partial<Timestamp>) => {
    onChange({
      ...video,
      timestamps: video.timestamps.map((ts) =>
        ts.id === id ? { ...ts, ...patch } : ts
      )
    });
  };

  const deleteTimestamp = (id: string) => {
    onChange({
      ...video,
      timestamps: video.timestamps.filter((ts) => ts.id !== id)
    });
  };

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    const reordered = Array.from(video.timestamps);
    const [moved] = reordered.splice(result.source.index, 1);
    reordered.splice(result.destination.index, 0, moved);
    onChange({ ...video, timestamps: reordered });
  };

  const saveNotes = (notes: string) => {
    if (!editingNotes) return;
    updateTimestamp(editingNotes.id, { notes });
    setEditingNotes(null);
  };

  return (
    <div>
      <h2>Timestamps</h2>
      <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
        <button onClick={addTimestampManual}>Add Manual</button>
        <button onClick={handleCapture}>📸 Capture Current Time</button>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="timestamp-list">
          {(provided) => (
            <ul
              ref={provided.innerRef}
              {...provided.droppableProps}
              style={{ listStyle: "none", padding: 0, marginTop: "12px" }}
            >
              {video.timestamps.map((ts, index) => (
                <Draggable key={ts.id} draggableId={ts.id} index={index}>
                  {(provided, snapshot) => (
                    <li
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      style={{
                        padding: "10px",
                        marginBottom: "8px",
                        border: "1px solid #ccc",
                        borderRadius: "6px",
                        background: snapshot.isDragging ? "#f0f0f0" : "white",
                        ...provided.draggableProps.style
                      }}
                    >
                      <div
                        {...provided.dragHandleProps}
                        style={{
                          cursor: "grab",
                          fontSize: "0.9em",
                          opacity: 0.7,
                          marginBottom: "4px"
                        }}
                      >
                        ⠿ Drag
                      </div>

                      <div>
                        <strong>{formatTime(ts.timeSeconds)}</strong> —{" "}
                        {ts.label}
                      </div>

                      <div
                        style={{
                          marginTop: "6px",
                          display: "flex",
                          gap: "8px",
                          flexWrap: "wrap"
                        }}
                      >
                        {onSeek && (
                          <button onClick={() => onSeek(ts.timeSeconds)}>
                            Jump
                          </button>
                        )}
                        <button
                          onClick={() => {
                            const newLabel =
                              prompt("Edit label:", ts.label) ?? ts.label;
                            updateTimestamp(ts.id, { label: newLabel });
                          }}
                        >
                          Edit
                        </button>
                        <button onClick={() => setEditingNotes(ts)}>
                          Notes
                        </button>
                        <button onClick={() => deleteTimestamp(ts.id)}>
                          Delete
                        </button>
                      </div>
                    </li>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </ul>
          )}
        </Droppable>
      </DragDropContext>

      <TimestampNotesModal
        timestamp={editingNotes}
        onSave={saveNotes}
        onClose={() => setEditingNotes(null)}
      />
    </div>
  );
}
