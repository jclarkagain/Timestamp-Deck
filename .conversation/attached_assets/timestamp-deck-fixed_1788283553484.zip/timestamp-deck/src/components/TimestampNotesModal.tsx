import { useEffect, useState } from "react";
import type { Timestamp } from "../types";
import { marked } from "marked";

type Props = {
  timestamp: Timestamp | null;
  onSave: (notes: string) => void;
  onClose: () => void;
};

export function TimestampNotesModal({ timestamp, onSave, onClose }: Props) {
  const [text, setText] = useState(timestamp?.notes ?? "");

  // Keep the textarea in sync whenever a different timestamp is opened for
  // editing (hooks must run unconditionally, so this replaces the old
  // `useState(timestamp.notes)` that only ran once on mount).
  useEffect(() => {
    setText(timestamp?.notes ?? "");
  }, [timestamp]);

  if (!timestamp) return null;

  return (
    <div className="modal-overlay">
      <div className="modal">
        <h2>Edit Notes</h2>
        <div style={{ display: "flex", gap: "16px" }}>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={12}
            style={{
              flex: 1,
              padding: "8px",
              border: "1px solid #ccc",
              borderRadius: "4px",
              fontFamily: "monospace"
            }}
            placeholder="Markdown supported..."
          />
          <div
            style={{
              flex: 1,
              padding: "8px",
              border: "1px solid #ccc",
              borderRadius: "4px",
              background: "#fafafa",
              overflowY: "auto"
            }}
            dangerouslySetInnerHTML={{ __html: marked.parse(text) as string }}
          />
        </div>
        <div className="modal-actions">
          <button onClick={onClose}>Cancel</button>
          <button onClick={() => onSave(text)}>Save Notes</button>
        </div>
      </div>
    </div>
  );
}
