import { useState } from "react";
import type { Project } from "../types";
import { decryptProject } from "../utils/crypto";

type Props = {
  isOpen: boolean;
  onClose: () => void;
  onImport: (project: Project) => void;
};

export function ImportModal({ isOpen, onClose, onImport }: Props) {
  const [jsonInput, setJsonInput] = useState("");
  const [password, setPassword] = useState("");
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleImport = async () => {
    if (!jsonInput.trim()) {
      setError("Paste encrypted JSON.");
      return;
    }
    if (!password) {
      setError("Enter password.");
      return;
    }

    setError(null);
    setIsDecrypting(true);

    try {
      const payload = JSON.parse(jsonInput);
      const project = await decryptProject(payload, password);
      onImport(project);
      setJsonInput("");
      setPassword("");
      onClose();
    } catch (err) {
      console.error(err);
      setError("Decryption failed. Check your password and pasted JSON.");
    } finally {
      setIsDecrypting(false);
    }
  };

  const handleCancel = () => {
    setJsonInput("");
    setPassword("");
    setError(null);
    onClose();
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <h2>Import Encrypted Project</h2>
        <p>Paste encrypted JSON and enter the password.</p>

        <label>Encrypted JSON</label>
        <textarea
          rows={6}
          value={jsonInput}
          onChange={(e) => setJsonInput(e.target.value)}
          disabled={isDecrypting}
        />

        <label>Password</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          disabled={isDecrypting}
        />

        {error && <div className="error">{error}</div>}

        <div className="modal-actions">
          <button onClick={handleCancel} disabled={isDecrypting}>
            Cancel
          </button>
          <button onClick={handleImport} disabled={isDecrypting}>
            {isDecrypting ? "Decrypting..." : "Decrypt & Import"}
          </button>
        </div>
      </div>
    </div>
  );
}
