import {
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
  forwardRef
} from "react";
import type { VideoEntry } from "../types";
import { loadYouTubeAPI } from "../utils/youtubeApi";

export type PlayerRef = {
  seekTo: (seconds: number) => void;
  getCurrentTime: () => number;
};

type Props = { video: VideoEntry };

function extractVideoId(url: string): string {
  try {
    const parsed = new URL(url);
    if (parsed.host.includes("youtu.be")) {
      return parsed.pathname.slice(1);
    }
    if (parsed.host.includes("youtube.com")) {
      return parsed.searchParams.get("v") || "";
    }
  } catch {
    // Malformed URL - fall through to empty string below.
  }
  return "";
}

export const VideoPlayer = forwardRef<PlayerRef, Props>(({ video }, ref) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const playerRef = useRef<YT.Player | null>(null);
  const [apiReady, setApiReady] = useState(false);

  useImperativeHandle(ref, () => ({
    seekTo: (seconds) => playerRef.current?.seekTo(seconds, true),
    getCurrentTime: () => playerRef.current?.getCurrentTime() ?? 0
  }));

  // Wait for the (asynchronously loaded) YouTube API before ever trying to
  // construct a player.
  useEffect(() => {
    let cancelled = false;
    loadYouTubeAPI().then(() => {
      if (!cancelled) setApiReady(true);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!apiReady || !containerRef.current) return;

    const videoId = extractVideoId(video.url);
    if (!videoId) return;

    if (playerRef.current) {
      playerRef.current.destroy();
      playerRef.current = null;
    }

    playerRef.current = new window.YT.Player(containerRef.current, {
      videoId,
      height: "390",
      width: "640",
      playerVars: { rel: 0 }
    });

    return () => {
      playerRef.current?.destroy();
      playerRef.current = null;
    };
  }, [apiReady, video.url]);

  return <div ref={containerRef} />;
});
