import { useEffect, useMemo, useRef, useState } from "react";
import type { Project, VideoEntry } from "./types";
import { useProjectStore } from "./hooks/useProjectStore";
import { VideoPlayer, PlayerRef } from "./components/VideoPlayer";
import { TimestampPanel } from "./components/TimestampPanel";
import { GlobalTimeline } from "./components/GlobalTimeline";
import { ImportModal } from "./components/ImportModal";
import { ExportPanel } from "./components/ExportPanel";

const createEmptyProject = (): Project => ({
  id: "proj-1",
  name: "My Timestamp Deck",
  videos: []
});

export function App() {
  const { project, setProject } = useProjectStore(createEmptyProject());
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  const [showGlobalTimeline, setShowGlobalTimeline] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [secureMode, setSecureMode] = useState(false);
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [searchQuery, setSearchQuery] = useState("");

  const playerRef = useRef<PlayerRef | null>(null);

  useEffect(() => {
    document.body.dataset.theme = theme;
  }, [theme]);

  const activeVideo: VideoEntry | undefined = useMemo(
    () =>
      project.videos.find((v) => v.id === activeVideoId) ?? project.videos[0],
    [project, activeVideoId]
  );

  useEffect(() => {
    if (!activeVideo && project.videos.length > 0) {
      setActiveVideoId(project.videos[0].id);
    }
  }, [project, activeVideo]);

  const addVideo = () => {
    const url = prompt("YouTube URL:");
    if (!url) return;
    const title = prompt("Title:") ?? url;
    const newVideo: VideoEntry = {
      id: `vid-${Date.now()}`,
      title,
      url,
      timestamps: []
    };
    setProject({ ...project, videos: [...project.videos, newVideo] });
    setActiveVideoId(newVideo.id);
  };

  const updateVideo = (updated: VideoEntry) => {
    setProject({
      ...project,
      videos: project.videos.map((v) => (v.id === updated.id ? updated : v))
    });
  };

  const jumpToTimestamp = (videoId: string, seconds: number) => {
    setActiveVideoId(videoId);
    setShowGlobalTimeline(false);
    setTimeout(() => {
      playerRef.current?.seekTo(seconds);
    }, 100);
  };

  const handleImport = (imported: Project) => {
    setProject(imported);
    if (imported.videos.length > 0) {
      setActiveVideoId(imported.videos[0].id);
    }
  };

  const getCurrentTime = () => playerRef.current?.getCurrentTime() ?? 0;

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // Don't hijack keystrokes while the user is typing anywhere
      // (search box, notes textarea, password fields, etc).
      const target = e.target as HTMLElement | null;
      const isTypingContext =
        !!target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable);
      if (isTypingContext) return;

      if (e.key === "c") {
        const time = getCurrentTime();
        if (!activeVideo) return;
        const label = prompt("Label for captured timestamp?") ?? "";
        const newVideo: VideoEntry = {
          ...activeVideo,
          timestamps: [
            ...activeVideo.timestamps,
            {
              id: `ts-${Date.now()}`,
              timeSeconds: Math.floor(time),
              label
            }
          ]
        };
        updateVideo(newVideo);
      }
      if (e.key === "f") {
        const el = document.querySelector<HTMLInputElement>(
          "input[placeholder^='Search']"
        );
        el?.focus();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [activeVideo, project]);

  return (
    <div className="app">
      <header className="header">
        <h1>Timestamp Deck</h1>
        <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
          <button onClick={() => setSecureMode((m) => !m)}>
            {secureMode ? "Secure Mode: ON" : "Secure Mode: OFF"}
          </button>
          <button
            onClick={() => setTheme((t) => (t === "light" ? "dark" : "light"))}
          >
            {theme === "light" ? "Dark Mode" : "Light Mode"}
          </button>
        </div>
      </header>

      <main className="layout">
        <aside className="sidebar">
          <h2>Videos</h2>
          <button onClick={addVideo}>Add Video</button>
          <ul>
            {project.videos.map((v) => (
              <li key={v.id}>
                <button
                  onClick={() => setActiveVideoId(v.id)}
                  style={{
                    fontWeight: v.id === activeVideoId ? "bold" : "normal"
                  }}
                >
                  {v.title}
                </button>
              </li>
            ))}
          </ul>

          <button
            onClick={() => setShowGlobalTimeline((s) => !s)}
            style={{ marginTop: "8px" }}
          >
            {showGlobalTimeline
              ? "Hide Global Timeline"
              : "Show Global Timeline"}
          </button>

          <button
            onClick={() => setIsImportModalOpen(true)}
            style={{ marginTop: "8px" }}
          >
            Import Encrypted Project
          </button>

          <ExportPanel project={project} secureMode={secureMode} />
        </aside>

        <section className="content">
          {showGlobalTimeline ? (
            <GlobalTimeline
              project={project}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              onJump={jumpToTimestamp}
            />
          ) : activeVideo ? (
            <>
              <VideoPlayer ref={playerRef} video={activeVideo} />
              <TimestampPanel
                video={activeVideo}
                onChange={updateVideo}
                onSeek={(seconds) => playerRef.current?.seekTo(seconds)}
                onCapture={getCurrentTime}
              />
            </>
          ) : (
            <p>Add a video to get started.</p>
          )}
        </section>
      </main>

      <ImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImport={handleImport}
      />
    </div>
  );
}
